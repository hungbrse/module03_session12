package com.example.session12.model.dao.book;

import com.example.session12.model.entity.Book;

import java.util.List;

public interface BookDao {

    List<Book> findAll();
    Boolean addNewBook(Book book);
    Boolean updateBook(Book book);
    Book findBookById(int id);
    void deleteBookById(int id);
}
