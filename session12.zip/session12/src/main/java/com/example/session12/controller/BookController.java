package com.example.session12.controller;

import com.example.session12.model.entity.Book;
import com.example.session12.model.service.book.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/book")
public class BookController {

    @Autowired
    private BookService bookService;
    @GetMapping
    public String index(Model model){
        List<Book> bookList = bookService.findAll();
        model.addAttribute("bookList",bookList);
        return "book/index";
    }

    @GetMapping("/add")
    public String add() {
        return "book/add";
    }
//
    @PostMapping("/add")
    public String addBook(@RequestParam String title, @RequestParam String author, @RequestParam double price) {
        Book newBook = new Book();
        newBook.setTitle(title);
        newBook.setAuthor(author);
        newBook.setPrice(price);
        bookService.addNewBook(newBook);
        return "redirect:/book"; // Chuyển hướng về danh sách sách sau khi thêm

    }
//
//    @GetMapping
//    public String edit() {
//        return "book/edit";
//    }


}
