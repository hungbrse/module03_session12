package com.example.session12.model.dao.book;

import com.example.session12.dataBase.ConectionDB;
import com.example.session12.model.entity.Book;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class BookImpl implements BookDao {
    @Override
    public List<Book> findAll() {
        Connection con = null;
        List<Book> bookList = new ArrayList<Book>();
        try {
            con = ConectionDB.openConnection();
            String sql = "select * from book";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Book book = new Book();
                book.setId(rs.getInt("id"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setPrice(rs.getDouble("price"));
                bookList.add(book);
            }
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return bookList;
    }

    @Override
    public Boolean addNewBook(Book book) {
        Connection connection = null;

        try {
            connection = ConectionDB.openConnection();
            CallableStatement statement = connection.prepareCall("{call proc_add(?,?,?)}");
            statement.setString(1, book.getTitle());
            statement.setString(2, book.getAuthor());
            statement.setDouble(3, book.getPrice());
            if (statement.executeUpdate() > 0) {
                return true;
            }

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            ConectionDB.closeConnection(connection);
        }
       return false;

    }

    @Override
    public Boolean updateBook(Book book) {
        return null;
    }

    @Override
    public Book findBookById(int id) {
        return null;
    }

    @Override
    public void deleteBookById(int id) {

    }
}
