package com.example.session12.model.service.book;

import com.example.session12.model.entity.Book;

import java.util.List;

public interface BookServiceImpl {

    List<Book> findAll();
    Boolean addNewBook(Book book);
    Boolean updateBook(Book book);
    Book findBookById(int id);
    void deleteBookById(int id);
}
